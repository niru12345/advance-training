package Medicine;



public interface MedicineInfo {
	void displayLabel();
}