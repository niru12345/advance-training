package Exception;

public class AgeNotWithinRangeException extends Exception{
	
	public AgeNotWithinRangeException(String mssg) {
		
		super(mssg);
	}

}
